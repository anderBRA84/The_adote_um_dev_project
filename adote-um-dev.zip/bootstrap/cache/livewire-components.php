<?php return array (
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'auth.passwords.confirm' => 'App\\Http\\Livewire\\Auth\\Passwords\\Confirm',
  'auth.passwords.email' => 'App\\Http\\Livewire\\Auth\\Passwords\\Email',
  'auth.passwords.reset' => 'App\\Http\\Livewire\\Auth\\Passwords\\Reset',
  'auth.register' => 'App\\Http\\Livewire\\Auth\\Register',
  'auth.verify' => 'App\\Http\\Livewire\\Auth\\Verify',
  'components.developers-screen' => 'App\\Http\\Livewire\\Components\\DevelopersScreen',
  'components.home-screen' => 'App\\Http\\Livewire\\Components\\HomeScreen',
  'components.interest-screen' => 'App\\Http\\Livewire\\Components\\InterestScreen',
  'components.preference-screen' => 'App\\Http\\Livewire\\Components\\PreferenceScreen',
  'components.splash-screen' => 'App\\Http\\Livewire\\Components\\SplashScreen',
);