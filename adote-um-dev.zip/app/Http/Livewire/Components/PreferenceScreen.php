<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;
use App\Models\Category;
use App\Models\Interest;
use App\Models\Preference;

class PreferenceScreen extends Component
{

    public $user;
    public $categories;
    public $payload;

    public function save(){

        try{
        $this->insertPreferencesData();
        //TODO::SOENVIAR PARA SE O CARA FOR DEV
        //$json = json_encode($this->payload);
        //$json = $this->sanitizeInterestsData();
        //$userId = auth()->user()->id;
        //dump($userId,$json);
            return redirect()->route('app.developers');
        } catch(\Exception $exception){
            //todo: add notoficacao
            dd($exception->getMessage());
        }



    }

    private function insertPreferencesData(){
        Preference::updateOrCreate([
            'user_id' => auth()->user()->id,
        ],[
            'data' => json_encode($this->payload),
        ]);

    }

    public function mount(){
        $this->user = auth()->user()->load('profile')->toArray();
        $this->categories = Category::with('skills')->get()->toArray();
       // $this->payload = [];
        //dd($this->categories);

    }

    public function render()
    {
        return view('livewire.components.preference-screen');
    }
}

