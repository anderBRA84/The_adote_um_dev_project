<?php

namespace App\Http\Livewire\Components;

use App\Models\Category;
use Livewire\Component;
use App\Models\Interest;



class InterestScreen extends Component
{
    public $user;
    public $categories;
    public $payload;


    public function save(){

        try{
        $this->insertInterestsData();
        dump($this->payload);
        //TODO::SOENVIAR PARA SE O CARA FOR DEV
        //$json = json_encode($this->payload);
        //$json = $this->sanitizeInterestsData();
        //$userId = auth()->user()->id;


        if (userIsDeveloper()){

            return redirect()->route('app.preference');
        }

            return redirect()->route('app.developers');
        } catch(\Exception $exception){
            //todo: add notoficacao
            dd($exception->getMessage());
        }



    }
    private function insertInterestsData(){
        Interest::updateOrCreate([
            'user_id' => auth()->user()->id,
        ],[
            'data' => json_encode($this->payload),

        ]);

        $json = json_last_error_msg();
        dump($json);

        }


    public function mount(){
        $this->user = auth()->user()->load('profile')->toArray();
        $this->categories = Category::with('skills:id,category_id,name')
        ->select('id','name')
        ->get()
        ->toArray();
       // $this->payload = [];
        //dd($this->categories);

    }
    public function render()
    {
        return view('livewire.components.interest-screen');
    }

}
