<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class SplashScreen extends Component
{
    public function render()
    {
        return view('livewire.components.splash-screen');
    }
}
