<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class DevelopersScreen extends Component
{
    public function render()
    {
        return view('livewire.components.developers-screen');
    }
}
