<?php


use App\Http\Livewire\Components\SplashScreen;
use App\Http\Livewire\Components\HomeScreen;
use App\Http\Livewire\Components\InterestScreen;
use App\Http\Livewire\Components\PreferenceScreen;
use App\Http\Livewire\Components\DevelopersScreen;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\Auth\GithubController;
use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;

    // rota de compoentes livewire onde os usuarios acessam sem estar autenticados
    Route::group(['namespace'=>'App\Http\Livewire\Components'],function(){
        Route::get( '/',SplashScreen::class)->name('app.splash');
        Route::get( '/home',HomeScreen::class)->name('app.home');
    });

    //rotas acessadas somente se o usuario estiver autenticado
    // tambem sao componentes do livewire
    Route::group(['middleware'=>'auth'],function(){
        Route::get( '/interest',InterestScreen::class)->name('app.interest');
        Route::get( '/preference',PreferenceScreen::class)->name('app.preference');
        Route::get( '/developers',DevelopersScreen::class)->name('app.developers');
    });

    //acessando essa rota cai em Auth/GithubController
    // quando o usuario realiza o login acessa o componente HomeScreen do livewire
    Route::get('/auth/redirectGithub', function () {
        return Socialite::driver('github')->redirect();
    })->name('socialite.redirect-github');

    //rota passada para callback/redirect  no oAuth do site github
    Route::get('/auth/github', GithubController::class);

    //acessando essa rota cai em Auth/GoogleController
    // quando o usuario realiza o login acessa o componente HomeScreen do livewire
    Route::get('/auth/redirectGoogle', function () {
        return Socialite::driver('Google')->redirect();
        })->name('socialite.redirect-google');

    //rota passada para callback/redirect no oAuth do site google
    Route::get('/auth/google', GoogleController::class);
