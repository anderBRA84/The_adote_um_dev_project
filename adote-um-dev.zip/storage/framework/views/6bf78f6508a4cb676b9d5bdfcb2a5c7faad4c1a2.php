<?php echo e($slot); ?>

<?php /**PATH /var/www/html/adote-um-dev/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>