<div>
    teste 2
</div>
<?php /**PATH /var/www/html/adote-um-dev/resources/views/livewire/components/developers-screen.blade.php ENDPATH**/ ?>