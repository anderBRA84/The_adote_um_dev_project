<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('sRmlBQ9')) {
    $componentId = $_instance->getRenderedChildComponentId('sRmlBQ9');
    $componentTag = $_instance->getRenderedChildComponentTagName('sRmlBQ9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sRmlBQ9');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('sRmlBQ9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH /var/www/html/adote-um-dev/vendor/livewire/livewire/src/Testing/../views/mount-component.blade.php ENDPATH**/ ?>