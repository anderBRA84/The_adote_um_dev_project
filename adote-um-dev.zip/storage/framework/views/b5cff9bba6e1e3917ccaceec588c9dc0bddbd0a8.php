<?php $__env->startSection('content'); ?>
    <div class="  flex flex-col items-center justify-center min-h-screen w-full bg-gradient-to-r from-primary-100 to-secondary-100">
        <div class="flex flex-row items-center justify-center w-full sapce-x-2">
        	<img src="<?php echo e(asset('assets/mstile-310x310.png')); ?>"/>
        </div>
        <span class="mr-0 text-white text-3xl font-bold"> ADOTE UM DEV</span>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/adote-um-dev/resources/views/welcome.blade.php ENDPATH**/ ?>