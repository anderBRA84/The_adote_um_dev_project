<div>
    
    <h1>Login feito com sucesso</h1>
</div>
<?php /**PATH /var/www/html/adote-um-dev/resources/views/sucesso.blade.php ENDPATH**/ ?>