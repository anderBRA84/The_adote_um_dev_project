<div>
    

    Anderson brabao
</div>
<?php /**PATH /var/www/html/adote-um-dev/resources/views/livewire/component/splash-screen.blade.php ENDPATH**/ ?>