<div>
    
    Aqui quem manda e o Anderson
</div>
<?php /**PATH /var/www/html/adote-um-dev/resources/views/livewire/splashscreen.blade.php ENDPATH**/ ?>