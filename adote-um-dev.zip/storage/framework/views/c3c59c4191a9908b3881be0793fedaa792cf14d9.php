<div  class="flex flex-col min-h-screen items-center w-full-p4 ">

    <div class=" flex flex-col items-center justify-center space-y-2">
        <div class="mt-10 sm:mt-0 w-full">
            <div class="md:col-span-1">
                <div class=" flex flex-col items-center justify-center space-y-2">
                    <img class="inline-block h-14 w-14 rounded-full ring-2 ring-white" src="<?php echo e($user['profile']['avatar']); ?>" alt="foto profile">
                    
                    <h3 class="text-lg font-medium leading-6 text-gray-900">Complete Suas Preferencias</h3>
                </div>
            <div class="mt-5">
                <form class="space-y-4">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.start-form','data' => ['categories' => $categories]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('start-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <div>
                        <button wire:click="save"
                        class="flex flex-row space-x-2 justify-center items-center bg-primary-100 p-4 text-white mt-4 w-full rounded-full mb-8 font-bold transform duration-150 active:scale-95 ">
                        <span>Cadastrar Preferencias</span>
                        </button>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH /var/www/html/adote-um-dev/resources/views/livewire/components/preference-screen.blade.php ENDPATH**/ ?>