import startForm from './start-form';


window.$components = {
    startForm
};

