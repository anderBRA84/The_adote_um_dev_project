<div  class="flex flex-col min-h-screen items-center w-full-p4 ">

    <div class=" flex flex-col items-center justify-center space-y-2">
        <div class="mt-10 sm:mt-0 w-full">
            <div class="md:col-span-1">
                <div class=" flex flex-col items-center justify-center space-y-2">
                    <img class="inline-block h-14 w-14 rounded-full ring-2 ring-white" src="{{$user['profile']['avatar']}}" alt="foto profile">
                    {{-- <span class="text-gray-100 font-bold">{{$user['profile']['nickname']}}</span> --}}
                    <h3 class="text-lg font-medium leading-6 text-gray-900">Complete Suas Preferencias</h3>
                </div>
            <div class="mt-5">
                <form class="space-y-4">
                    <x-start-form :categories="$categories"/>

                    <div>
                        <button wire:click="save"
                        class="flex flex-row space-x-2 justify-center items-center bg-primary-100 p-4 text-white mt-4 w-full rounded-full mb-8 font-bold transform duration-150 active:scale-95 ">
                        <span>Cadastrar Preferencias</span>
                        </button>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>


