show tables
